// main.js
const API_BASE = '/api/portfolio/';
const WS_URL = `wss://${window.location.host}/ws/stats/`;

// WebSocket Connection
const socket = new WebSocket(WS_URL);
socket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    updateLiveStats(data);
};

// Fetch portfolio data
async function loadPortfolioData() {
    try {
        const [projects, skills] = await Promise.all([
            fetch(`${API_BASE}projects/`).then(res => res.json()),
            fetch(`${API_BASE}skills/`).then(res => res.json())
        ]);
        
        renderProjects(projects);
        renderSkills(skills);
    } catch (error) {
        showError('Failed to load portfolio data');
    }
}

// Contact form handler
document.getElementById('contact-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    try {
        const response = await fetch('/api/chat/contact/', {
            method: 'POST',
            body: JSON.stringify(Object.fromEntries(formData)),
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (response.ok) {
            showSuccess('Message sent successfully!');
            e.target.reset();
        }
    } catch (error) {
        showError('Failed to send message');
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadPortfolioData();
    initLiveUpdates();
});

// Initialize Chat
document.addEventListener('DOMContentLoaded', () => {
    // Load previous messages
    fetch('/api/chat/messages/')
        .then(res => res.json())
        .then(messages => {
            messages.forEach(msg => appendMessage(msg));
        });
});